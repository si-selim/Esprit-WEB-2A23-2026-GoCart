-- =============================================
-- Base de données : EspritStand
-- Table : stand
-- =============================================

CREATE DATABASE IF NOT EXISTS EspritStand;
USE EspritStand;

CREATE TABLE IF NOT EXISTS stand (
    ID_stand INT AUTO_INCREMENT PRIMARY KEY,
    ID_parcours INT NOT NULL,
    nom_stand VARCHAR(100) NOT NULL,
    position VARCHAR(100) NOT NULL,
    description TEXT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Quelques enregistrements
INSERT INTO stand (ID_parcours, nom_stand, position, description) VALUES
(1, 'Stand Hydratation', 'Km 5', 'Stand de distribution d''eau et boissons énergétiques'),
(1, 'Stand Nutrition', 'Km 10', 'Stand de ravitaillement avec barres énergétiques et fruits'),
(2, 'Stand Souvenir', 'Arrivée', 'Stand de vente de souvenirs et médailles'),
(2, 'Stand Premium', 'Km 15', 'Stand VIP avec massage et récupération'),
(3, 'Stand Outdoor', 'Départ', 'Stand d''équipement outdoor et accessoires de course');
