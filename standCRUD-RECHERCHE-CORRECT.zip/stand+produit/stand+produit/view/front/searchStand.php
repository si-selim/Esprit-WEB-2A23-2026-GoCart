<?php
require_once __DIR__ . '/../../controller/standcontroller.php';

$message = "";
$standTrouve = null;
$messageClass = "";

// Récupérer la valeur du champ
if (isset($_REQUEST['searchVal'])) {
    $searchVal = trim($_REQUEST['searchVal']);
    
    if (!empty($searchVal)) {
        $controller = new StandController();
        // searchStand utilise déjà PDO prepare
        $standTrouve = $controller->searchStand($searchVal);
        
        if ($standTrouve) {
            $message = "✅ Stand trouvé !";
            $messageClass = "success-msg";
        } else {
            $message = "❌ Stand introuvable.";
            $messageClass = "error-msg";
        }
    } else {
        $message = "Veuillez entrer un ID ou nom de stand à rechercher.";
        $messageClass = "error-msg";
    }
} else {
    $message = "Aucune requête de recherche reçue.";
    $messageClass = "error-msg";
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Recherche de Stand</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body { background-color: #f4f7f6; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .search-result-container {
            max-width: 600px;
            margin: 50px auto;
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.05);
            text-align: center;
        }
        .search-result-container h1 { font-size: 24px; margin-bottom: 20px; color: #333; }
        .success-msg { color: #28a745; font-weight: bold; font-size: 18px; margin-bottom: 20px;}
        .error-msg { color: #dc3545; font-weight: bold; font-size: 18px; margin-bottom: 20px;}
        .stand-details {
            background: #f9f9fc;
            border: 1px solid #e1e5ee;
            padding: 20px;
            border-radius: 8px;
            text-align: left;
            margin-bottom: 25px;
        }
        .stand-details p { margin: 10px 0; font-size: 16px; color: #555; }
        .stand-details strong { color: #222; display: inline-block; width: 120px; }
        .btn-retour {
            display: inline-block;
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            transition: 0.3s;
        }
        .btn-retour:hover { background-color: #0056b3; }
    </style>
</head>
<body>
    <div class="search-result-container">
        <h1>Résultat de la recherche</h1>
        
        <div class="<?= $messageClass ?>"><?= htmlspecialchars($message) ?></div>

        <?php if ($standTrouve): ?>
            <div class="stand-details">
                <p><strong>ID Stand:</strong> <?= htmlspecialchars($standTrouve['ID_stand']) ?></p>
                <p><strong>ID Parcours:</strong> <?= htmlspecialchars($standTrouve['ID_parcours']) ?></p>
                <p><strong>Nom:</strong> <?= htmlspecialchars($standTrouve['nom_stand']) ?></p>
                <p><strong>Position:</strong> <?= htmlspecialchars($standTrouve['position']) ?></p>
                <p><strong>Description:</strong> <?= htmlspecialchars($standTrouve['description']) ?></p>
            </div>
        <?php endif; ?>
        
        <a href="crud-stand.html" class="btn-retour">⬅ Retour à la gestion</a>
    </div>
</body>
</html>
