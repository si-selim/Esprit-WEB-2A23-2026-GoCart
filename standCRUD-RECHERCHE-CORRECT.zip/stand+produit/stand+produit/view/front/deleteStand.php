<?php
require_once __DIR__ . '/../../controller/standcontroller.php';

$controller = new StandController();

if (isset($_GET['id']) && ctype_digit($_GET['id'])) {
    $controller->deleteStand((int) $_GET['id']);
    header("Location: crud-stand.php?msg=deleted");
    exit;
} else {
    header("Location: crud-stand.php?msg=error");
    exit;
}