<?php
require_once __DIR__ . '/../../controller/standcontroller.php';

// Instantiate the controller and get the list of stands
$standController = new StandController();
$listStands = $standController->listStands();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | Trail de Zaghouan</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
    <div class="dashboard">
        <aside class="admin-sidebar">
            <div class="admin-profile">
                <div class="sidebar-logo">
                    <img src="logo.png" alt="Logo" class="sidebar-logo-img">
                </div>
                <div class="admin-info">
                    <div class="admin-name">Admin </div>
                    <div class="admin-role">Administrateur - admin</div>
                </div>
            </div>
            <nav class="nav-menu">
                <a class="nav-item active" href="../front/stand.html" data-menu="catalogue">📋 Catalogue</a>
                <a class="nav-item" href="#" data-menu="ajouter">➕ Ajouter un marathon</a>
                <a class="nav-item" href="#" data-menu="statistiques">📊 Statistiques</a>
                <a class="nav-item" href="#" data-menu="utilisateurs">👥 Utilisateurs</a>
                <a class="nav-item" href="#" data-menu="marathons">🏁 Marathons</a>
                <a class="nav-item" href="#" data-menu="parcours">🗺️ Parcours</a>
                <a class="nav-item" href="#" data-menu="stands">🏪 Stands</a>
                <a class="nav-item" href="#" data-menu="produits">📦 Produits</a>
                <a class="nav-item" href="#" data-menu="reclamations">💬 Réclamations</a>
                <a class="nav-item logout" href="#" data-menu="logout">🚪 Se déconnecter</a>
            </nav>
            <div class="sync-footer">
                🔄 4/4HZ / ADAPTIVE SYNC
            </div>
        </aside>

        <main class="main-content">
            <section class="page-section" id="catalogue">
                <div class="card">
                    <div class="card-header">
                        <h2>Catalogue</h2>
                    </div>
                    
                </div>
            </section>

            <section class="page-section hidden" id="ajouter">
                <div class="card">
                    <div class="card-header">
                        <h2>Ajouter un nouveau marathon</h2>
                    </div>
                    <div class="card-content">
                        <p>Cette section sera utilisée pour ajouter un marathon, avec son nom, sa date, son parcours et sa description.</p>
                    </div>
                </div>
            </section>

            <section class="page-section hidden" id="statistiques">
                <div class="card">
                    <div class="card-header">
                        <h2>Statistiques</h2>
                    </div>
                    <div class="card-content">
                        <p>Affiche les performances, le nombre de stands et le nombre de produits disponibles.</p>
                    </div>
                </div>
            </section>

            <section class="page-section hidden" id="utilisateurs">
                <div class="card">
                    <div class="card-header">
                        <h2>Utilisateurs</h2>
                    </div>
                    <div class="card-content">
                        <p>Section de gestion des utilisateurs : suivi des comptes et des rôles.</p>
                    </div>
                </div>
            </section>

            <section class="page-section hidden" id="marathons">
                <div class="card">
                    <div class="card-header">
                        <h2>Marathons</h2>
                    </div>
                    <div class="card-content">
                        <p>Affiche les marathons programmés, leurs distances et leurs détails.</p>
                    </div>
                </div>
            </section>

            <section class="page-section hidden" id="parcours">
                <div class="card">
                    <div class="card-header">
                        <h2>Parcours</h2>
                    </div>
                    <div class="card-content">
                        <p>Affiche les parcours associés aux marathons, avec leurs points de départ et d’arrivée.</p>
                    </div>
                </div>
            </section>

            <section class="page-section hidden" id="stands-section">
                <div class="event-header">
                    <div class="event-title">
                        <h1>Présentation des stands</h1>
                    </div>
                    <div class="event-meta">
                        <span>🏁 Stands disponibles</span>
                        <span>📏 Informations générales</span>
                        <span>⚡ Mise à jour en temps réel</span>
                        <span>📍 Tous les lieux</span>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h2>Tous les stands</h2>
                    </div>
                    <div class="table-wrapper">
                        <table>
                            <thead>
                                <tr>
                                    <th>Marathon</th>
                                    <th>ID stand</th>
                                    <th>Nom</th>
                                    <th>Catégorie</th>
                                    <th>Description</th>
                                    <th>Produits disponibles</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($listStands)): ?>
                                    <tr>
                                        <td colspan="6" style="text-align: center; padding: 20px; font-weight: bold; color: #666;">
                                            Aucun stand n'est actuellement enregistré dans la base de données.
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($listStands as $stand): ?>
                                    <tr>
                                        <td>Parcours #<?= htmlspecialchars($stand['ID_parcours']); ?></td>
                                        <td><span class="badge-id">#<?= htmlspecialchars($stand['ID_stand']); ?></span></td>
                                        <td><?= htmlspecialchars($stand['nom_stand']); ?></td>
                                        <td><?= htmlspecialchars($stand['position']); ?></td>
                                        <td><?= htmlspecialchars($stand['description']); ?></td>
                                        <td><span class="produit-count">0</span></td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>

            <section class="page-section hidden" id="produits-section">
                <div class="card">
                    <div class="card-header">
                        <h2>Tous les produits</h2>
                    </div>
                    <div class="table-wrapper">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID Produit</th>
                                    <th>Nom Produit</th>
                                    <th>Type</th>
                                    <th>ID Stand</th>
                                    <th>Prix</th>
                                    <th>Quantité</th>
                                    <th>Stock</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>101</td>
                                    <td>Gilet</td>
                                    <td>Accessoire</td>
                                    <td>1</td>
                                    <td>15</td>
                                    <td>25</td>
                                    <td>Disponible</td>
                                </tr>
                                <tr>
                                    <td>102</td>
                                    <td>Bouteille</td>
                                    <td>Boisson</td>
                                    <td>2</td>
                                    <td>3</td>
                                    <td>50</td>
                                    <td>Disponible</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>

            <section class="page-section hidden" id="reclamations-section">
                <div class="card">
                    <div class="card-header reclamations-header">
                        <h2>Réclamations</h2>
                    </div>
                    <div class="table-wrapper">
                        <table>
                            <thead>
                                <tr>
                                    <th>Commande</th>
                                    <th>Marathon</th>
                                    <th>Stand</th>
                                    <th>Participant</th>
                                    <th>Status</th>
                                    <th>Messages</th>
                                    <th>Dernier message</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="8" class="empty-message">
                                        <p>Aucune réclamation ou discussion pour le moment.</p>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>
        </main>
    </div>
    <script>
        const navItems = document.querySelectorAll('.nav-item');
        const mainContent = document.querySelector('.main-content');
        const sections = {
            catalogue: document.getElementById('catalogue'),
            ajouter: document.getElementById('ajouter'),
            statistiques: document.getElementById('statistiques'),
            utilisateurs: document.getElementById('utilisateurs'),
            marathons: document.getElementById('marathons'),
            parcours: document.getElementById('parcours'),
            stands: document.getElementById('stands-section'),
            produits: document.getElementById('produits-section'),
            reclamations: document.getElementById('reclamations-section')
        };

        function hideAllSections() {
            Object.values(sections).forEach(section => {
                if (section) {
                    section.classList.add('hidden');
                }
            });
        }

        navItems.forEach(item => {
            item.addEventListener('click', event => {
                const href = item.getAttribute('href');
                if (href && href !== '#') {
                    return;
                }
                event.preventDefault();
                const target = item.getAttribute('data-menu');

                navItems.forEach(nav => nav.classList.remove('active'));
                item.classList.add('active');

                hideAllSections();
                if (target && sections[target]) {
                    sections[target].classList.remove('hidden');
                    mainContent.classList.remove('hidden');
                } else {
                    mainContent.classList.add('hidden');
                }
            });
        });
    </script>
</body>
</html>
