<?php
session_start();
require_once __DIR__ . '/../../controller/standcontroller.php';
require_once __DIR__ . '/../../controller/produitcontroller.php';

// Instantiate controllers
$standController = new StandController();
$produitController = new ProduitController();

// Handle Stand Sorting
$standSort = isset($_GET['standSort']) ? $_GET['standSort'] : (isset($_SESSION['standSort']) ? $_SESSION['standSort'] : 'ID_stand');
$standOrder = isset($_GET['standOrder']) ? $_GET['standOrder'] : (isset($_SESSION['standOrder']) ? $_SESSION['standOrder'] : 'ASC');
$_SESSION['standSort'] = $standSort;
$_SESSION['standOrder'] = $standOrder;

// Handle Produit Sorting
$produitSort = isset($_GET['produitSort']) ? $_GET['produitSort'] : (isset($_SESSION['produitSort']) ? $_SESSION['produitSort'] : 'ID_produit');
$produitOrder = isset($_GET['produitOrder']) ? $_GET['produitOrder'] : (isset($_SESSION['produitOrder']) ? $_SESSION['produitOrder'] : 'ASC');
$_SESSION['produitSort'] = $produitSort;
$_SESSION['produitOrder'] = $produitOrder;

$listStands = $standController->listStands($standSort, $standOrder);
$listProduits = $produitController->listProduits($produitSort, $produitOrder);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | Trail de Zaghouan</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
    <div class="dashboard">
        <aside class="admin-sidebar">
            <div class="admin-profile">
                <div class="sidebar-logo">
                    <img src="logo.png" alt="Logo" class="sidebar-logo-img">
                </div>
                <div class="admin-info">
                    <div class="admin-name">Admin </div>
                    <div class="admin-role">Administrateur - admin</div>
                </div>
            </div>
            <nav class="nav-menu">
                <a class="nav-item active" href="../front/stand.html" data-menu="catalogue">📋 Catalogue</a>
                <a class="nav-item" href="#" data-menu="ajouter">➕ Ajouter un marathon</a>
                <a class="nav-item" href="#" data-menu="statistiques">📊 Statistiques</a>
                <a class="nav-item" href="#" data-menu="utilisateurs">👥 Utilisateurs</a>
                <a class="nav-item" href="#" data-menu="marathons">🏁 Marathons</a>
                <a class="nav-item" href="#" data-menu="parcours">🗺️ Parcours</a>
                <a class="nav-item" href="#" data-menu="stands">🏪 Stands</a>
                <a class="nav-item" href="#" data-menu="produits">📦 Produits</a>
                <a class="nav-item" href="#" data-menu="reclamations">💬 Réclamations</a>
                <a class="nav-item logout" href="#" data-menu="logout">🚪 Se déconnecter</a>
            </nav>
            <div class="sync-footer">
                🔄 4/4HZ / ADAPTIVE SYNC
            </div>
        </aside>

        <main class="main-content">
            <section class="page-section" id="catalogue">
                <div class="card">
                    <div class="card-header">
                        <h2>Catalogue</h2>
                    </div>
                    
                </div>
            </section>

            <section class="page-section hidden" id="ajouter">
                <div class="card">
                    <div class="card-header">
                        <h2>Ajouter un nouveau marathon</h2>
                    </div>
                    <div class="card-content">
                        <p>Cette section sera utilisée pour ajouter un marathon, avec son nom, sa date, son parcours et sa description.</p>
                    </div>
                </div>
            </section>

            <section class="page-section hidden" id="statistiques">
                <div class="card">
                    <div class="card-header">
                        <h2>📊 Rapports et Analyses</h2>
                    </div>
                    <div class="card-content" style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; padding: 20px;">
                        <div style="background: #f8fafc; border: 1px solid #e2e8f0; padding: 30px; border-radius: 12px; text-align: center; transition: 0.3s; cursor: pointer;" onmouseover="this.style.transform='translateY(-5px)'" onmouseout="this.style.transform='none'" onclick="window.location.href='../front/stat.html'">
                            <div style="font-size: 40px; margin-bottom: 15px;">🏪</div>
                            <h3 style="color: #006056; margin-bottom: 10px;">Activité des Stands</h3>
                            <p style="color: #64748b; font-size: 14px;">Visualisez quel stand est le plus actif et combien de produits chaque stand possède.</p>
                            <span style="display: inline-block; margin-top: 15px; color: #0984e3; font-weight: bold;">Voir le graphique →</span>
                        </div>
                        
                        <div style="background: #f8fafc; border: 1px solid #e2e8f0; padding: 30px; border-radius: 12px; text-align: center; transition: 0.3s; cursor: pointer;" onmouseover="this.style.transform='translateY(-5px)'" onmouseout="this.style.transform='none'" onclick="window.location.href='../front/statP.html'">
                            <div style="font-size: 40px; margin-bottom: 15px;">📦</div>
                            <h3 style="color: #006056; margin-bottom: 10px;">État des Stocks</h3>
                            <p style="color: #64748b; font-size: 14px;">Analysez la répartition de vos produits entre "En Stock" et "En Rupture".</p>
                            <span style="display: inline-block; margin-top: 15px; color: #0984e3; font-weight: bold;">Voir le graphique →</span>
                        </div>
                    </div>
                </div>
            </section>

            <section class="page-section hidden" id="utilisateurs">
                <div class="card">
                    <div class="card-header">
                        <h2>Utilisateurs</h2>
                    </div>
                    <div class="card-content">
                        <p>Section de gestion des utilisateurs : suivi des comptes et des rôles.</p>
                    </div>
                </div>
            </section>

            <section class="page-section hidden" id="marathons">
                <div class="card">
                    <div class="card-header">
                        <h2>Marathons</h2>
                    </div>
                    <div class="card-content">
                        <p>Affiche les marathons programmés, leurs distances et leurs détails.</p>
                    </div>
                </div>
            </section>

            <section class="page-section hidden" id="parcours">
                <div class="card">
                    <div class="card-header">
                        <h2>Parcours</h2>
                    </div>
                    <div class="card-content">
                        <p>Affiche les parcours associés aux marathons, avec leurs points de départ et d’arrivée.</p>
                    </div>
                </div>
            </section>

            <section class="page-section hidden" id="stands-section">
                <div class="event-header">
                    <div class="event-title">
                        <h1>Présentation des stands</h1>
                    </div>
                    <div class="event-meta">
                        <span>🏁 Stands disponibles</span>
                        <span>📏 Informations générales</span>
                        <span>⚡ Mise à jour en temps réel</span>
                        <span>📍 Tous les lieux</span>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
                        <h2>Tous les stands</h2>
                        <button onclick="exportTableToPDF('stands-table', 'liste_stands.pdf', 'Rapport des Stands')" style="background: #2d3436; color: white; border: none; padding: 8px 15px; border-radius: 6px; cursor: pointer; display: flex; align-items: center; gap: 8px; font-weight: 600; font-size: 13px; transition: 0.3s;">
                            <span style="font-size: 16px;">📄</span> Exporter PDF
                        </button>
                    </div>
                    <div class="table-wrapper">
                        <table id="stands-table">
                            <thead>
                                <tr>
                                    <th><a href="?standSort=ID_parcours&standOrder=<?= ($standSort == 'ID_parcours' && $standOrder == 'ASC') ? 'DESC' : 'ASC'; ?>&section=stands" style="color:inherit; text-decoration:none;">Marathon ⇅</a></th>
                                    <th><a href="?standSort=ID_stand&standOrder=<?= ($standSort == 'ID_stand' && $standOrder == 'ASC') ? 'DESC' : 'ASC'; ?>&section=stands" style="color:inherit; text-decoration:none;">ID stand ⇅</a></th>
                                    <th><a href="?standSort=nom_stand&standOrder=<?= ($standSort == 'nom_stand' && $standOrder == 'ASC') ? 'DESC' : 'ASC'; ?>&section=stands" style="color:inherit; text-decoration:none;">Nom ⇅</a></th>
                                    <th><a href="?standSort=position&standOrder=<?= ($standSort == 'position' && $standOrder == 'ASC') ? 'DESC' : 'ASC'; ?>&section=stands" style="color:inherit; text-decoration:none;">Catégorie ⇅</a></th>
                                    <th><a href="?standSort=description&standOrder=<?= ($standSort == 'description' && $standOrder == 'ASC') ? 'DESC' : 'ASC'; ?>&section=stands" style="color:inherit; text-decoration:none;">Description ⇅</a></th>
                                    <th>Produits disponibles</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($listStands)): ?>
                                    <tr>
                                        <td colspan="7" style="text-align: center; padding: 20px; font-weight: bold; color: #666;">
                                            Aucun stand n'est actuellement enregistré dans la base de données.
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($listStands as $stand): ?>
                                    <tr id="row-<?= htmlspecialchars($stand['ID_stand']); ?>" data-id="<?= htmlspecialchars($stand['ID_stand']); ?>">
                                        <td class="editable" data-field="ID_parcours"><?= htmlspecialchars($stand['ID_parcours']); ?></td>
                                        <td><span class="badge-id">#<?= htmlspecialchars($stand['ID_stand']); ?></span></td>
                                        <td class="editable" data-field="nom_stand"><?= htmlspecialchars($stand['nom_stand']); ?></td>
                                        <td class="editable" data-field="position"><?= htmlspecialchars($stand['position']); ?></td>
                                        <td class="editable" data-field="description"><?= htmlspecialchars($stand['description']); ?></td>
                                        <td><span class="produit-count"><?= $produitController->countProduitsByStand((int)$stand['ID_stand']); ?></span></td>
                                        <td class="actions-cell">
                                            <button onclick="toggleEdit(this, <?= $stand['ID_stand']; ?>)" class="btn-action edit" style="background:#0984e3; color:white; border:none; padding:5px 10px; border-radius:4px; cursor:pointer; font-size:12px; margin-right:5px;">Modifier</button>
                                            <a href="../front/deleteStand.php?id=<?= $stand['ID_stand']; ?>" class="btn-action delete" style="background:#d63031; color:white; padding:5px 10px; border-radius:4px; text-decoration:none; font-size:12px; display:inline-block;" onclick="return confirm('Voulez-vous vraiment supprimer ce stand ?');">Supprimer</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>
            
            <section class="page-section hidden" id="produits-section">
                <div class="event-header">
                    <div class="event-title">
                        <h1>Gestion des produits</h1>
                    </div>
                    <div class="event-meta">
                        <span>📦 Produits en stock</span>
                        <span>💰 Gestion des prix</span>
                        <span>⚡ Mise à jour en temps réel</span>
                        <span>🏪 Tous les stands</span>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header" style="display: flex; justify-content: space-between; align-items: center;">
                        <h2>Tous les produits </h2>
                        <button onclick="exportTableToPDF('products-table', 'liste_produits.pdf', 'Catalogue des Produits')" style="background: #2d3436; color: white; border: none; padding: 8px 15px; border-radius: 6px; cursor: pointer; display: flex; align-items: center; gap: 8px; font-weight: 600; font-size: 13px; transition: 0.3s;">
                            <span style="font-size: 16px;">📄</span> Exporter PDF
                        </button>
                    </div>
                    <div class="table-wrapper">
                        <table id="products-table">
                            <thead>
                                <tr>
                                    <th><a href="?produitSort=ID_produit&produitOrder=<?= ($produitSort == 'ID_produit' && $produitOrder == 'ASC') ? 'DESC' : 'ASC'; ?>&section=produits" style="color:inherit; text-decoration:none;">ID ⇅</a></th>
                                    <th><a href="?produitSort=nom_produit&produitOrder=<?= ($produitSort == 'nom_produit' && $produitOrder == 'ASC') ? 'DESC' : 'ASC'; ?>&section=produits" style="color:inherit; text-decoration:none;">Nom ⇅</a></th>
                                    <th><a href="?produitSort=type&produitOrder=<?= ($produitSort == 'type' && $produitOrder == 'ASC') ? 'DESC' : 'ASC'; ?>&section=produits" style="color:inherit; text-decoration:none;">Type ⇅</a></th>
                                    <th><a href="?produitSort=ID_stand&produitOrder=<?= ($produitSort == 'ID_stand' && $produitOrder == 'ASC') ? 'DESC' : 'ASC'; ?>&section=produits" style="color:inherit; text-decoration:none;">Stand ⇅</a></th>
                                    <th><a href="?produitSort=prix_produit&produitOrder=<?= ($produitSort == 'prix_produit' && $produitOrder == 'ASC') ? 'DESC' : 'ASC'; ?>&section=produits" style="color:inherit; text-decoration:none;">Prix ⇅</a></th>
                                    <th><a href="?produitSort=qte_stock&produitOrder=<?= ($produitSort == 'qte_stock' && $produitOrder == 'ASC') ? 'DESC' : 'ASC'; ?>&section=produits" style="color:inherit; text-decoration:none;">Quantité ⇅</a></th>
                                    <th><a href="?produitSort=en_out_stock&produitOrder=<?= ($produitSort == 'en_out_stock' && $produitOrder == 'ASC') ? 'DESC' : 'ASC'; ?>&section=produits" style="color:inherit; text-decoration:none;">Stock ⇅</a></th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($listProduits)): ?>
                                    <tr>
                                        <td colspan="8" style="text-align: center; padding: 20px; font-weight: bold; color: #666;">
                                            Aucun produit enregistré dans la base de données.
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($listProduits as $prod): ?>
                                    <tr id="row-prod-<?= $prod->getIDProduit(); ?>" data-id="<?= $prod->getIDProduit(); ?>">
                                        <td><span class="badge-id">#<?= $prod->getIDProduit(); ?></span></td>
                                        <td class="editable-prod" data-field="nom_produit"><?= htmlspecialchars($prod->getNomProduit()); ?></td>
                                        <td class="editable-prod" data-field="type"><?= htmlspecialchars($prod->getType()); ?></td>
                                        <td class="editable-prod" data-field="ID_stand"><?= htmlspecialchars($prod->getIDStand()); ?></td>
                                        <td class="editable-prod" data-field="prix_produit"><?= htmlspecialchars($prod->getPrixProduit()); ?></td>
                                        <td class="editable-prod" data-field="qte_stock"><?= htmlspecialchars($prod->getQteStock()); ?></td>
                                        <td class="editable-prod" data-field="en_out_stock"><?= (stripos($prod->getEnOutStock(), 'dispo') !== false || $prod->getEnOutStock() === '1') ? '1' : '0'; ?></td>
                                        <td class="actions-cell">
                                            <button onclick="toggleEditProd(this, <?= $prod->getIDProduit(); ?>)" class="btn-action edit" style="background:#0984e3; color:white; border:none; padding:5px 10px; border-radius:4px; cursor:pointer; font-size:12px; margin-right:5px;">Modifier</button>
                                            <a href="../front/deleteProduit.php?id=<?= $prod->getIDProduit(); ?>" class="btn-action delete" style="background:#d63031; color:white; padding:5px 10px; border-radius:4px; text-decoration:none; font-size:12px; display:inline-block;" onclick="return confirm('Voulez-vous vraiment supprimer ce produit ?');">Supprimer</a>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>

            <section class="page-section hidden" id="reclamations-section">
                <div class="card">
                    <div class="card-header reclamations-header">
                        <h2>Réclamations</h2>
                    </div>
                    <div class="table-wrapper">
                        <table>
                            <thead>
                                <tr>
                                    <th>Commande</th>
                                    <th>Marathon</th>
                                    <th>Stand</th>
                                    <th>Participant</th>
                                    <th>Status</th>
                                    <th>Messages</th>
                                    <th>Dernier message</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td colspan="8" class="empty-message">
                                        <p>Aucune réclamation ou discussion pour le moment.</p>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </section>
        </main>
    </div>
    <!-- jsPDF and AutoTable libraries -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>

    <script>
        // PDF Export function
        function exportTableToPDF(tableId, filename, title) {
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();

            // Add title
            doc.setFontSize(18);
            doc.text(title, 14, 22);
            doc.setFontSize(11);
            doc.setTextColor(100);
            doc.text("Généré le: " + new Date().toLocaleString(), 14, 30);

            // Extract table data manually to avoid HTML garbage in headers
            const table = document.getElementById(tableId);
            const headers = [];
            const rows = [];

            // Get headers (only text, excluding the last one 'Actions')
            const ths = table.querySelectorAll('thead th');
            for (let i = 0; i < ths.length - 1; i++) {
                // Remove the arrows (⇅) and take clean text
                headers.push(ths[i].innerText.replace(' ⇅', '').trim());
            }

            // Get rows (excluding the last cell 'Actions')
            const trs = table.querySelectorAll('tbody tr');
            trs.forEach(tr => {
                const row = [];
                const tds = tr.querySelectorAll('td');
                if (tds.length > 1) { // Skip empty/colspan rows
                    for (let i = 0; i < tds.length - 1; i++) {
                        row.push(tds[i].innerText.trim());
                    }
                    rows.push(row);
                }
            });

            // Export table
            doc.autoTable({
                head: [headers],
                body: rows,
                startY: 35,
                theme: 'striped',
                headStyles: { fillColor: [0, 96, 86], textColor: [255, 255, 255] },
                margin: { top: 35 }
            });

            doc.save(filename);
        }

        const navItems = document.querySelectorAll('.nav-item');
        const mainContent = document.querySelector('.main-content');
        const sections = {
            catalogue: document.getElementById('catalogue'),
            ajouter: document.getElementById('ajouter'),
            statistiques: document.getElementById('statistiques'),
            utilisateurs: document.getElementById('utilisateurs'),
            marathons: document.getElementById('marathons'),
            parcours: document.getElementById('parcours'),
            stands: document.getElementById('stands-section'),
            produits: document.getElementById('produits-section'),
            reclamations: document.getElementById('reclamations-section')
        };

        function hideAllSections() {
            Object.values(sections).forEach(section => {
                if (section) {
                    section.classList.add('hidden');
                }
            });
        }

        navItems.forEach(item => {
            item.addEventListener('click', event => {
                const href = item.getAttribute('href');
                if (href && href !== '#') {
                    return;
                }
                event.preventDefault();
                const target = item.getAttribute('data-menu');

                navItems.forEach(nav => nav.classList.remove('active'));
                item.classList.add('active');

                hideAllSections();
                if (target && sections[target]) {
                    sections[target].classList.remove('hidden');
                    mainContent.classList.remove('hidden');
                } else {
                    mainContent.classList.add('hidden');
                }
            });
        });

        // ==========================
        // AUTO OPEN SECTION FROM URL
        // ==========================
        const urlParams = new URLSearchParams(window.location.search);
        const sectionParam = urlParams.get('section');
        
        if (sectionParam && sections[sectionParam]) {
            hideAllSections();
            sections[sectionParam].classList.remove('hidden');
            // Update active state in sidebar
            navItems.forEach(nav => {
                if (nav.getAttribute('data-menu') === sectionParam) {
                    nav.classList.add('active');
                } else {
                    nav.classList.remove('active');
                }
            });
        }

        // ==========================
        // INLINE EDIT LOGIC (STANDS)
        // ==========================
        let isEditing = false; // Prevents editing multiple rows at once
        
        function toggleEdit(btn, id) {
            if (isEditing) {
                alert("Veuillez enregistrer la ligne en cours d'édition avant d'en modifier une autre.");
                return;
            }

            const row = document.getElementById('row-' + id);
            const editables = row.querySelectorAll('.editable');
            
            editables.forEach(td => {
                const text = td.innerText;
                const fieldName = td.getAttribute('data-field');
                // Create an input for each editable field
                let inputType = (fieldName === 'ID_parcours') ? 'number' : 'text';
                td.innerHTML = `<input type="${inputType}" class="inline-input" value="${text}" style="width:100%; padding:4px;" />`;
            });
            
            isEditing = true;
            
            // Change "Modifier" to "Enregistrer"
            btn.innerHTML = "Enregistrer";
            btn.style.background = "#27ae60"; // Green color
            btn.setAttribute('onclick', `saveStand(this, ${id})`);
        }

        function saveStand(btn, id) {
            const row = document.getElementById('row-' + id);
            const editables = row.querySelectorAll('.editable');
            
            // Use FormData (No JSON)
            const formData = new FormData();
            formData.append('ID_stand', id);
            editables.forEach(td => {
                const input = td.querySelector('input');
                const fieldName = td.getAttribute('data-field');
                formData.append(fieldName, input.value);
            });
            
            fetch('../front/updateStandAjax.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(result => {
                if(result === 'SUCCESS') {
                    editables.forEach(td => {
                        const input = td.querySelector('input');
                        td.innerHTML = input.value;
                    });
                    isEditing = false;
                    btn.innerHTML = "Modifier";
                    btn.style.background = "#0984e3";
                    btn.setAttribute('onclick', `toggleEdit(this, ${id})`);
                } else {
                    alert('Erreur: ' + result);
                }
            })
            .catch(error => {
                console.error('Erreur:', error);
                alert("Une erreur est survenue.");
            });
        }

        // ==========================
        // INLINE EDIT LOGIC (PRODUCTS)
        // ==========================
        function toggleEditProd(btn, id) {
            if (isEditing) {
                alert("Veuillez enregistrer l'élément en cours d'édition avant d'en modifier un autre.");
                return;
            }

            const row = document.getElementById('row-prod-' + id);
            const editables = row.querySelectorAll('.editable-prod');
            
            editables.forEach(td => {
                const text = td.innerText;
                const fieldName = td.getAttribute('data-field');
                let inputType = (fieldName === 'prix_produit' || fieldName === 'qte_stock' || fieldName === 'ID_stand') ? 'number' : 'text';
                td.innerHTML = `<input type="${inputType}" class="inline-input" value="${text}" style="width:100%; padding:4px;" />`;
            });
            
            isEditing = true;
            btn.innerHTML = "Enregistrer";
            btn.style.background = "#27ae60";
            btn.setAttribute('onclick', `saveProduit(this, ${id})`);
        }

        function saveProduit(btn, id) {
            const row = document.getElementById('row-prod-' + id);
            const editables = row.querySelectorAll('.editable-prod');
            
            const formData = new FormData();
            formData.append('ID_produit', id);
            editables.forEach(td => {
                const input = td.querySelector('input');
                const fieldName = td.getAttribute('data-field');
                formData.append(fieldName, input.value);
            });
            
            fetch('../front/updateProduitAjax.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(result => {
                if(result === 'SUCCESS') {
                    editables.forEach(td => {
                        const input = td.querySelector('input');
                        td.innerHTML = input.value;
                    });
                    isEditing = false;
                    btn.innerHTML = "Modifier";
                    btn.style.background = "#0984e3";
                    btn.setAttribute('onclick', `toggleEditProd(this, ${id})`);
                } else {
                    alert('Erreur: ' + result);
                }
            })
            .catch(error => {
                console.error('Erreur:', error);
                alert("Une erreur est survenue.");
            });
        }
    </script>

    </script>

</body>
</html>
