<?php
// getStandsByParcours.php
header('Content-Type: application/json');

require_once __DIR__ . '/../../controller/standcontroller.php';

if (isset($_GET['id_parcours'])) {
    $idParcours = intval($_GET['id_parcours']);
    $controller = new StandController();
    $stands = $controller->getStandsByParcours($idParcours);
    
    echo json_encode(['success' => true, 'data' => $stands]);
} else {
    echo json_encode(['success' => false, 'message' => 'Paramètre id_parcours manquant']);
}
?>
