<?php
require_once __DIR__ . '/../../controller/produitcontroller.php';

$message = "";
$produitTrouve = null;
$messageClass = "";

// Récupérer la valeur du champ
if (isset($_REQUEST['searchVal'])) {
    $searchVal = trim($_REQUEST['searchVal']);
    
    if (!empty($searchVal)) {
        $controller = new ProduitController();
        $results = $controller->searchProduits($searchVal);
        $produitTrouve = !empty($results) ? $results[0] : null;
        
        if ($produitTrouve) {
            $message = "✅ Produit trouvé !";
            $messageClass = "success-msg";
        } else {
            $message = "❌ Produit introuvable.";
            $messageClass = "error-msg";
        }
    } else {
        $message = "Veuillez entrer un ID ou nom de produit à rechercher.";
        $messageClass = "error-msg";
    }
} else {
    $message = "Aucune requête de recherche reçue.";
    $messageClass = "error-msg";
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Recherche de Produit</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .result-card {
            max-width: 600px;
            margin: 50px auto;
            background: #fff;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            text-align: center;
        }
        .success-msg { color: #27ae60; font-weight: bold; font-size: 1.2em; margin-bottom: 20px; }
        .error-msg { color: #e74c3c; font-weight: bold; font-size: 1.2em; margin-bottom: 20px; }
        .product-details { text-align: left; background: #f9f9f9; padding: 20px; border-radius: 10px; margin-top: 20px; }
        .product-details p { margin: 10px 0; font-size: 1.1em; }
        .btn-back { display: inline-block; margin-top: 30px; padding: 12px 25px; background: #006056; color: white; text-decoration: none; border-radius: 8px; font-weight: bold; }
    </style>
</head>
<body>
    <div class="result-card">
        <div class="<?= $messageClass ?>"><?= $message ?></div>

        <?php if ($produitTrouve): ?>
            <div class="product-details">
                <p><strong>ID Produit:</strong> <?= htmlspecialchars($produitTrouve->getIDProduit()) ?></p>
                <p><strong>Nom produit:</strong> <?= htmlspecialchars($produitTrouve->getNomProduit()) ?></p>
                <p><strong>Prix:</strong> <?= htmlspecialchars($produitTrouve->getPrixProduit()) ?> TND</p>
                <p><strong>Type:</strong> <?= htmlspecialchars($produitTrouve->getType()) ?></p>
                <p><strong>Quantité en stock:</strong> <?= htmlspecialchars($produitTrouve->getQteStock()) ?></p>
                <p><strong>État stock:</strong> <?= ($produitTrouve->getEnOutStock() === 'Disponible') ? '1' : '0'; ?></p>
            </div>
        <?php endif; ?>

        <a href="crud-produit.html" class="btn-back">← Retour à la gestion</a>
    </div>
</body>
</html>
