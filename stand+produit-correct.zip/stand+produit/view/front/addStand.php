<?php
require_once __DIR__ . '/../../controller/standcontroller.php';

$controller = new StandController();

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $idStand     = isset($_POST['ID_stand']) && !empty($_POST['ID_stand']) ? (int) $_POST['ID_stand'] : null;
    $idParcours  = isset($_POST['idParcours']) ? (int) $_POST['idParcours'] : null;
    $nomStand    = isset($_POST['nomStand']) ? trim($_POST['nomStand']) : null;
    $position    = isset($_POST['position']) ? trim($_POST['position']) : null;
    $description = isset($_POST['description']) ? trim($_POST['description']) : null;

    if ($idParcours && $nomStand && $position && $description) {

        // Crée l'objet Stand
        $stand = new Stand(
            $idStand,
            $idParcours,
            $nomStand,
            $position,
            $description
        );

        // Vérifier si l'ID existe déjà pour faire UPDATE au lieu de INSERT
        $existingStand = null;
        if ($idStand) {
            $existingStand = $controller->getStandByValue((string)$idStand);
        }

        if ($existingStand) {
            // C'est un UPDATE
            if ($controller->updateStand($stand, $idStand)) {
                echo "<script>alert('✅ Stand modifié avec succès !'); window.location.href='../back/tab_stand.php?section=stands';</script>";
                exit;
            } else {
                echo "<script>alert('❌ Erreur lors de la modification du stand.'); window.location.href='../back/tab_stand.php?section=stands';</script>";
                exit;
            }
        } else {
            // C'est un INSERT
            if ($controller->addStand($stand)) {
                echo "<script>alert('✅ Stand ajouté avec succès !'); window.location.href='../back/tab_stand.php?section=stands';</script>";
                exit;
            } else {
                echo "<script>alert('❌ Erreur lors de l\'ajout du stand.'); window.location.href='../back/tab_stand.php?section=stands';</script>";
                exit;
            }
        }

    } else {
        echo "<script>alert('❌ Erreur: tous les champs sont obligatoires.'); window.location.href='../back/tab_stand.php?section=stands';</script>";
        exit;
    }
}
?>