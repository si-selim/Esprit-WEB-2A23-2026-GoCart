<?php
require_once __DIR__ . '/../../controller/produitcontroller.php';

$controller = new ProduitController();

if (isset($_GET['id']) && ctype_digit($_GET['id'])) {
    if ($controller->deleteProduit((int)$_GET['id'])) {
        header("Location: ../back/tab_stand.php?section=produits&msg=deleted");
    } else {
        header("Location: ../back/tab_stand.php?section=produits&msg=error");
    }
} else {
    header("Location: ../back/tab_stand.php?section=produits");
}
exit;
?>
