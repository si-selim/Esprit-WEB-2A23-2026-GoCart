<?php
require_once __DIR__ . '/../../controller/produitcontroller.php';

$controller = new ProduitController();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $idProduit    = isset($_POST['idProduit']) && !empty($_POST['idProduit']) ? (int)$_POST['idProduit'] : null;
    $idStand      = isset($_POST['idStand']) ? (int)$_POST['idStand'] : null;
    $nomProduit   = isset($_POST['nomProduit']) ? trim($_POST['nomProduit']) : null;
    $type         = isset($_POST['type']) ? trim($_POST['type']) : null;
    $prixProduit  = isset($_POST['prixProduit']) ? (float)$_POST['prixProduit'] : null;
    $qteStock     = isset($_POST['quantiteStock']) ? (int)$_POST['quantiteStock'] : null;
    $enOutStock   = isset($_POST['stock']) ? $_POST['stock'] : null;

    // On garde directement 1 ou 0 comme demandé par l'utilisateur
    if ($enOutStock === "1" || $enOutStock === 1 || (is_string($enOutStock) && stripos($enOutStock, 'dispo') !== false)) {
        $enOutStock = "1";
    } else {
        $enOutStock = "0";
    }

    $action = $_POST['action'] ?? 'add';

    if ($idStand && $nomProduit && $type && $prixProduit !== null && $qteStock !== null && $enOutStock) {
        try {
            if ($action === 'update' && $idProduit) {
                $produit = new Produit($idProduit, $idStand, $nomProduit, $type, $prixProduit, $qteStock, $enOutStock);
                if ($controller->updateProduit($produit)) {
                    echo "<script>alert('✅ Produit modifié avec succès !'); window.location.href='../back/tab_stand.php?section=produits';</script>";
                } else {
                    echo "<script>alert('❌ Erreur lors de la modification. Vérifiez si l\'ID existe.'); history.back();</script>";
                }
            } else {
                // ADD MODE
                $produit = new Produit(null, $idStand, $nomProduit, $type, $prixProduit, $qteStock, $enOutStock);
                
                // On essaie d'ajouter et on capture les erreurs précises
                if ($controller->addProduit($produit)) {
                    echo "<script>alert('✅ Produit ajouté avec succès !'); window.location.href='../back/tab_stand.php?section=produits';</script>";
                } else {
                    echo "<script>alert('❌ L\'ajout a échoué. Vérifiez que l\'ID Stand ($idStand) existe bien dans la table stands.'); history.back();</script>";
                }
            }
        } catch (Exception $e) {
            echo "<h1>Erreur Système</h1>";
            echo "Détails : " . htmlspecialchars($e->getMessage());
            echo "<br><br><button onclick='history.back()'>Retour</button>";
            exit;
        }
    } else {
        echo "<script>alert('❌ Erreur : Certains champs sont vides ou invalides.'); history.back();</script>";
    }
}
?>
