<?php
require_once __DIR__ . '/../../controller/standcontroller.php';

if (isset($_REQUEST['searchVal'])) {
    $searchVal = trim($_REQUEST['searchVal']);
    $controller = new StandController();
    $standTrouve = $controller->getStandByValue($searchVal);

    if ($standTrouve) {
        $html = file_get_contents('crud-stand.html');
        
        // Injecter dynamiquement les données dans le HTML
        $html = str_replace(
            'name="ID_stand" placeholder="ID Stand"', 
            'name="ID_stand" placeholder="ID Stand" value="' . htmlspecialchars($standTrouve['ID_stand']) . '" readonly style="background:#eee; cursor:not-allowed;" title="L\'ID ne peut pas être modifié"', 
            $html
        );
        $html = str_replace(
            'name="nom_stand" placeholder="Nom Stand"', 
            'name="nom_stand" placeholder="Nom Stand" value="' . htmlspecialchars($standTrouve['nom_stand']) . '"', 
            $html
        );
        $html = str_replace(
            'name="position" placeholder="Position"', 
            'name="position" placeholder="Position" value="' . htmlspecialchars($standTrouve['position']) . '"', 
            $html
        );
        $html = str_replace(
            'name="ID_parcours" placeholder="ID Parcours"', 
            'name="ID_parcours" placeholder="ID Parcours" value="' . htmlspecialchars($standTrouve['ID_parcours']) . '"', 
            $html
        );
        $html = str_replace(
            '<textarea id="description" name="description" placeholder="Description" rows="4"></textarea>', 
            '<textarea id="description" name="description" placeholder="Description" rows="4">' . htmlspecialchars($standTrouve['description']) . '</textarea>', 
            $html
        );
        
        // Afficher un msg amical
        $msg = "<div style='background-color:#d1fae5; color:#065f46; font-weight:bold; padding: 15px; text-align:center; margin-bottom:20px; border-radius: 8px;'>✅ Stand trouvé : Mode Modification activé. Sauvegardez en cliquant sur \"Ajouter\".</div>";
        $html = str_replace('<div class="form-header">', $msg . '<div class="form-header">', $html);
        
        echo $html;
        exit;
    } else {
        echo "<script>alert('❌ Stand introuvable.'); window.location.href='crud-stand.html';</script>";
        exit;
    }
} else {
    // Si on arrive sans recherche (ex: en cliquant directement)
    header("Location: crud-stand.html");
    exit;
}
?>