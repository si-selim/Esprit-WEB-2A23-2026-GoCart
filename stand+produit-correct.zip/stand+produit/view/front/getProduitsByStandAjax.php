<?php
// getProduitsByStandAjax.php - VERSION SANS JSON
require_once __DIR__ . '/../../controller/produitcontroller.php';

$idStand = isset($_GET['id_stand']) ? (int)$_GET['id_stand'] : 0;

if ($idStand > 0) {
    $controller = new ProduitController();
    $produits = $controller->listProduits(); // On peut filtrer par stand si une méthode existe, sinon on filtre ici
    
    // On simule SUCCESS|Nom;Type;Prix;Stock|Nom;Type;Prix;Stock
    $response = "SUCCESS";
    $found = false;
    foreach ($produits as $prod) {
        if ((int)$prod['ID_stand'] === $idStand) {
            $response .= "|" . $prod['nom_produit'] . ";" . $prod['type'] . ";" . $prod['prix_produit'] . ";" . $prod['qte_stock'];
            $found = true;
        }
    }
    
    if (!$found) {
        echo "EMPTY";
    } else {
        echo $response;
    }
} else {
    echo "ERROR";
}
?>
