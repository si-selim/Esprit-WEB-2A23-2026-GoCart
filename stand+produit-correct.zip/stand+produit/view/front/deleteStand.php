<?php
require_once __DIR__ . '/../../controller/standcontroller.php';

$controller = new StandController();

if (isset($_GET['id']) && ctype_digit($_GET['id'])) {
    $controller->deleteStand((int) $_GET['id']);
    header("Location: ../back/tab_stand.php?section=stands&msg=deleted");
    exit;
} else {
    header("Location: ../back/tab_stand.php?section=stands");
    exit;
}