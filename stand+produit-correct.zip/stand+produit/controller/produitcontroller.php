<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../model/produitModel.php';

class ProduitController {
    public function listProduits(?string $sort = null, ?string $order = 'ASC') {
        return Produit::findAll($sort, $order);
    }

    public function addProduit(Produit $produit) {
        return $produit->save();
    }

    public function deleteProduit(int $id) {
        $produit = Produit::findById($id);
        if ($produit) {
            return $produit->delete();
        }
        return false;
    }

    public function getProduit(int $id) {
        return Produit::findById($id);
    }

    public function searchProduits(string $search) {
        return Produit::search($search);
    }

    public function updateProduit(Produit $produit) {
        return $produit->save();
    }

    public function getProduitsByStand(int $idStand) {
        return Produit::findByStandId($idStand);
    }

    public function countProduitsByStand(int $idStand) {
        $db = config::getConnexion();
        $stmt = $db->prepare("SELECT COUNT(*) as total FROM produit WHERE ID_stand = ?");
        $stmt->execute([$idStand]);
        $res = $stmt->fetch();
        return $res ? (int)$res['total'] : 0;
    }
}
