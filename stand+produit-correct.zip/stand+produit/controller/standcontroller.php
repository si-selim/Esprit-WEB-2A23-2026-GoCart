<?php

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../model/standModel.php';

class StandController {

    // =====================
    // LIST (READ ALL)
    // =====================
    public function listStands($sort = null, $order = 'ASC') {
        $sql = "SELECT * FROM stand";
        
        $allowedSorts = ['ID_parcours', 'ID_stand', 'nom_stand', 'position', 'description'];
        if ($sort && in_array($sort, $allowedSorts)) {
            $order = ($order === 'DESC') ? 'DESC' : 'ASC';
            $sql .= " ORDER BY $sort $order";
        }

        $db = config::getConnexion();

        try {
            $query = $db->query($sql);
            return $query->fetchAll();
        } catch (Exception $e) {
            die('Error: ' . $e->getMessage());
        }
    }

    // =====================
    // GET BY PARCOURS
    // =====================
    public function getStandsByParcours($idParcours) {
        $sql = "SELECT * FROM stand WHERE ID_parcours = :ID_parcours";
        $db = config::getConnexion();

        try {
            $query = $db->prepare($sql);
            $query->bindValue(':ID_parcours', (int) $idParcours, PDO::PARAM_INT);
            $query->execute();
            return $query->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log('getStandsByParcours error: ' . $e->getMessage());
            return [];
        }
    }

    // =====================
    // ADD
    // =====================
    public function addStand($stand) {
        $sql = "INSERT INTO stand (ID_parcours, nom_stand, position, description) 
                VALUES (:ID_parcours, :nom_stand, :position, :description)";
        $db = config::getConnexion();

        $query = $db->prepare($sql);

        try {
            $query->execute([
                'ID_parcours'  => $stand->getIdParcours(),
                'nom_stand'    => $stand->getNomStand(),
                'position'     => $stand->getPosition(),
                'description'  => $stand->getDescription()
            ]);
            return true;
        } catch (Exception $e) {
            error_log('addStand error: ' . $e->getMessage());
            return false;
        }
    }

    // =====================
    // DELETE
    // =====================
    public function deleteStand($idStand) {
        $sql = "DELETE FROM stand WHERE ID_stand = :ID_stand";
        $db = config::getConnexion();

        $req = $db->prepare($sql);
        $req->bindValue(':ID_stand', (int) $idStand, PDO::PARAM_INT);

        try {
            $req->execute();
            return true;
        } catch (Exception $e) {
            error_log('deleteStand error: ' . $e->getMessage());
            return false;
        }
    }

    // =====================
    // DELETE BY VALUE (ID OR NAME)
    // =====================
    public function deleteStandByValue($valeur) {
        $stand = $this->searchStand($valeur);
        if ($stand && isset($stand['ID_stand'])) {
            return $this->deleteStand($stand['ID_stand']);
        }
        return false;
    }

    // =====================
    // GET BY ID (prepared statement)
    // =====================
    public function getStand($idStand) {
        $sql = "SELECT * FROM stand WHERE ID_stand = :ID_stand";
        $db = config::getConnexion();

        try {
            $query = $db->prepare($sql);
            $query->bindValue(':ID_stand', (int) $idStand, PDO::PARAM_INT);
            $query->execute();

            return $query->fetch();

        } catch (Exception $e) {
            error_log('getStand error: ' . $e->getMessage());
            return null;
        }
    }

    // =====================
    // SEARCH BY ID OR NAME
    // =====================
    public function searchStand($search) {
        $db = config::getConnexion();

        try {
            // Si c'est un nombre, chercher par ID d'abord
            if (ctype_digit(trim($search))) {
                $query = $db->prepare("SELECT * FROM stand WHERE ID_stand = :id");
                $query->bindValue(':id', (int) $search, PDO::PARAM_INT);
                $query->execute();
                $result = $query->fetch();

                if ($result) {
                    return $result;
                }
            }

            // Sinon chercher par nom
            $query = $db->prepare("SELECT * FROM stand WHERE nom_stand LIKE :nom LIMIT 1");
            $query->bindValue(':nom', '%' . $search . '%');
            $query->execute();

            return $query->fetch();

        } catch (Exception $e) {
            error_log('searchStand error: ' . $e->getMessage());
            return null;
        }
    }

    // =====================
    // ALIAS REQUESTED BY USER
    // =====================
    public function getStandByValue($valeur) {
        return $this->searchStand($valeur);
    }

    // =====================
    // UPDATE
    // =====================
    public function updateStand($stand, $idStand) {
        try {
            $db = config::getConnexion();

            $query = $db->prepare(
                'UPDATE stand SET 
                    ID_parcours = :ID_parcours,
                    nom_stand = :nom_stand,
                    position = :position,
                    description = :description
                WHERE ID_stand = :ID_stand'
            );

            $query->execute([
                'ID_stand'     => (int) $idStand,
                'ID_parcours'  => $stand->getIdParcours(),
                'nom_stand'    => $stand->getNomStand(),
                'position'     => $stand->getPosition(),
                'description'  => $stand->getDescription()
            ]);

            return true;

        } catch (PDOException $e) {
            error_log('updateStand error: ' . $e->getMessage());
            return false;
        }
    }
}